
Apprendre à utiliser les attributs css suivants :

- transition 
https://developer.mozilla.org/fr/docs/Web/CSS/CSS_Transitions/Utiliser_transitions_CSS
- transform 
https://developer.mozilla.org/fr/docs/Web/CSS/transform
- z-index
https://developer.mozilla.org/fr/docs/Web/CSS/z-index

- rgba

https://www.w3schools.com/cssref/func_rgba.asp


